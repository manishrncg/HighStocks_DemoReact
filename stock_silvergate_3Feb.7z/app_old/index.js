import React from 'react';
import ReactDOM from 'react-dom';
import FetchStockData from './components/FetchStockData.js';

class Mystocks extends React.Component {
  // constructor(){
  //   super();
  //    this.state = {
  //     weatherData: ''
  //   }
  //   // this.getData = this.getData.bind(this);
  // }

  // getData(data){
  //   // console.log(data);
  //   //  this.state = {
  //   //   weatherData: data
  //   // }
  //   if(JSON.stringify(this.state.weatherData) != JSON.stringify(data) && this.state.weatherData == ''){
  //       this.setState({weatherData: data});
  //   }
  // }

  render(){
    // console.log(this.state); onRecieveData={this.getData}  <Weathertab data={this.state} />
    return (<div>
	        <FetchStockData />
	      </div>);
  }
}

// ========================================

ReactDOM.render(
  <Mystocks />,
  document.getElementById('tabs')
);