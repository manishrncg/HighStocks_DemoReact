import React from 'react';
import ReactDOM from 'react-dom';
import FetchStockData from './components/FetchStockData.js';

class Mystocks extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      type: 'default',
      stock: 'MSFT'
    }

    this.changeType = this.changeType.bind(this);
  }
  changeType(e){
    console.log(e.target.value);
    this.setState({
      type: e.target.name=="type"?e.target.value:'default',
      stock: e.target.name=="stock"?e.target.value:'MSFT'
    })
  }

  render(){
    // console.log(this.state); onRecieveData={this.getData}  <Weathertab data={this.state} />
    return (<div>
	        <FetchStockData type={this.state.type} stock={this.state.stock} />
          <select name="type" onChange={e => this.changeType(e)}>
            <option value="default">Default</option>
            <option value="line">Line</option>
            <option value="column">Column</option>
            <option value="scatter">Scatter</option>
          </select>

          <input list="stocks" name="stock" onChange={e => this.changeType(e)} />
          <datalist id="stocks" >
            <option value="MSFT" >Microsoft</option>
            <option value="FB" >FB</option>
            <option value="AAPL" >Apple</option>
            <option value="20MICRONS" >20 Microns</option>
            <option value="21STCENMGM" >21st Cent. Mgmt.</option>
            <option value="3MINDIA" >3M India</option>
            <option value="ORCL" >Oracle Corp. Stock Price</option>
            <option value="CSCO" >Cisco Systems, Inc. (MM) Stock Price</option>
            <option value="TURN" >180 Degree Capital Corp.</option>
            <option value="VNET" >21Vianet Group, Inc.</option>
            <option value="FLWS" >1-800 FLOWERS.COM, Inc.</option>
            <option value="ZNGA" >Zynga Inc.</option>
            <option value="WIX" >Wix.com Ltd.</option>
            <option value="WEB" >Web.com Group, Inc.</option>
          </datalist>
	      </div>);
  }
}

// ========================================

ReactDOM.render(
  <Mystocks />,
  document.getElementById('tabs')
);